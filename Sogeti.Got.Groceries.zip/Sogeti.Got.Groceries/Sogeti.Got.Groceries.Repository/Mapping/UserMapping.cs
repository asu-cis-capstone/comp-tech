﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Sogeti.Got.Groceries.Data.DomainModels;
using System.Data.Entity.ModelConfiguration;

namespace Gogeti.Got.Groceries.Repository.Mapping
{
    class UserMapping : EntityTypeConfiguration<Users>
    {
        public UserMapping()
        {
            HasKey(t => t.Id);
            ToTable("Users", "dbo");

        }
    }
}

