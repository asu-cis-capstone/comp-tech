﻿using sogeti.got.groceries.Data.DomainModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sogeti.got.groceries.Repository
{
    public interface IListRepository
    {
        void addList(List l);

        List<List> getListByID(int uID);
        List<List> getShoppingList(int uId);
        List<List> getFavorites(int uId);
        void MakeFavorites(int lid);
        void DeleteList(int id);

    }
    public class ListRepository : IListRepository
    {
        private AppDbContext _context;

        public ListRepository()
        {
            _context = new AppDbContext();
        }

        public void addList(List l)
        {
            _context.List.Add(l);
            _context.SaveChanges();
        }

        public List<List> getListByID(int uID)
        {
            var query = from i in _context.List
                        where i.UserID == uID
                        select i;
            return query.ToList();
        }

        public List<List> getShoppingList(int uID)
        {
            var query = from i in _context.List
                        where (i.UserID == uID)
                        && (i.ListName.Contains("@shopping"))
                        select i;

            //if (query == null)
            //{
            //    List empty = new List();
            //    empty.ListName = "empty";
            //    return empty;
            //}
            return query.ToList();
        }

        public List<List> getFavorites(int uID)
        {
            var query = from i in _context.List
                        where (i.UserID == uID)
                        && (i.ListName.Contains("@favorite"))
                        select i;
            return query.ToList();
        }

        public void MakeFavorites(int lid)
        {
            var query = from i in _context.List
                         where (i.ListID == lid)
                         select i;
            List q = query.FirstOrDefault();
            q.ListName = q.ListName.Substring(0, q.ListName.IndexOf("@")+1) + "favorite";

            _context.SaveChanges();

        }
        public void DeleteList(int id)
        {
            var query = from i in _context.List
                        where i.ListID == id
                        select i;

            foreach (List list in query)
            {
                _context.List.Remove(list);
            }
            _context.SaveChanges();
        }

    }
}
