﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using sogeti.got.groceries.app.Models;
using System.Web.Security;
using sogeti.got.groceries.Business;
using sogeti.got.groceries.Data.ViewModels;
using sogeti.got.groceries.Data.DomainModels;

namespace sogeti.got.groceries.app.Controllers
{
    public class UsersController : Controller
    {
        private IUserManager _userManager;

        public UsersController()
        {
            _userManager = new UserManager();
        }

        [HttpGet]
        public ActionResult LogIn()
        {
            return View();
        }

        [HttpPost]
        public ActionResult LogIn(UserViewModel u)
        {
            if (_userManager.Login(u))
            {
                Session["uid"] = _userManager.returnUID();
                FormsAuthentication.SetAuthCookie(u.UserName, false);
                return RedirectToAction("ShoppingView", "List");
            }
            else
            {
                ModelState.AddModelError("", "Login details are wrong.");
                //ViewBag.Message = "Incorrect Login infromation";
            }
            //if (_userManager.IsValid(Request.Form["UserViewModel.UserName"], Request.Form["UserViewModel.Password"]))
            //{
            //    FormsAuthentication.SetAuthCookie(u.UserName, false);
            //    return RedirectToAction("Index", "Home");
            //}
            //else
            //{
            //    //ViewBag.Message = "Data successfully saved.";
            //    ModelState.AddModelError("", "Login details are wrong.");
            //}


            return View(u);
        }


        public ActionResult ShowUsers()
        {
            var items = _userManager.GetAllItems();

            return View(items);
        }

        public ActionResult ShowItem()
        {
            var items = _userManager.GetAllItems();

            return View(items);
        }


        [HttpGet]
        public ActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Register(Users u)
        {
            if (ModelState.IsValid)
            {
                //you should check duplicate registration here 
                u.RegDate = DateTime.Now;
                _userManager.AddUser(u);
                ModelState.Clear();

                //ViewBag.Message = "Successfully Registration Done";
                return RedirectToAction("Login", "Users");


            }
            

            return View();
        }

        public ActionResult LogOut()
        {
            Session.Clear();
            FormsAuthentication.SignOut();
            return RedirectToAction("Index", "Home");
        }

        //private bool IsValid(string userName, string password)
        //{
        //    bool IsValid = false;

        //    using (var db = new Repository.AppDbContext())

        //    {
        //        var user = db.Users.FirstOrDefault(u => u.UserName == userName);

        //        if (user != null)
        //        {
        //            if (user.Password == password)
        //            {
        //                IsValid = true;
        //            }
        //        }
        //    }
        //    return IsValid;
        //}




        ////GET
        //[HttpGet]
        //public ActionResult Register()
        //{
        //    return View();
        //}

        ////POST
        //// [ValidateAntiForgeryToken]
        //[HttpPost]
        //public ActionResult Register(User U)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        using (db)
        //        {
        //            //you should check duplicate registration here 
        //            db.Users.Add(U);
        //            db.SaveChanges();
        //            ModelState.Clear();
        //            U = null;
        //            ViewBag.Message = "Successfully Registration Done";
        //            //return RedirectToAction("Index", "Home");
        //        }
        //    }
        //    return View(U);
        //}

        ////GET
        //[HttpGet]
        //public ActionResult Login()
        //{
        //    return View();
        //}

        ////POST

        ////[ValidateAntiForgeryToken]
        //[HttpPost]
        //public ActionResult Login(User u)
        //{
        //    // this action is for handle post (login)
        //    //if (ModelState.IsValid) // this is check validity
        //    //{
        //    //    using (db)
        //    //    {
        //    //        var v = db.Users.Where(a => a.UserName.Equals(u.UserName) && a.Password.Equals(u.Password)).FirstOrDefault();
        //    //        if (v != null)
        //    //        {
        //    //            Session["LogedUserID"] = v.Id.ToString();
        //    //            Session["LogedUserFullname"] = v.FirstName.ToString();
        //    //            return RedirectToAction("AfterLogin");
        //    //        }
        //    //    }
        //    //}
        //    if (IsValid(u.UserName, u.Password))
        //    {
        //        FormsAuthentication.SetAuthCookie(u.UserName, false);
        //        return RedirectToAction("Index");
        //        //FormsAuthentication.SetAuthCookie(u.UserName, false);
        //        //return RedirectToAction("Index", "Home");
        //    }
        //    else
        //    {
        //        ModelState.AddModelError("", "Login details are wrong.");
        //    }
        //    return View(u);
        //}

        //private bool IsValid(string userName, string password)

        //{
        //    bool IsValid = false;

        //    using (var db = new sogeti.got.groceries.app.Models.GroceryListEntities())

        //    {
        //        var user = db.Users.FirstOrDefault(u => u.UserName == userName);

        //        if (user != null)
        //        {
        //            if (user.Password == password)
        //            {
        //                IsValid = true;
        //            }
        //        }
        //    }
        //    return IsValid;
        //}
        //public ActionResult AfterLogin()
        //{
        //    if (Session["LogedUserID"] != null)
        //    {
        //        return View();
        //    }
        //    else
        //    {
        //        return RedirectToAction("Index");
        //    }
        //}


        //public ActionResult LogOut()
        //{
        //    FormsAuthentication.SignOut();
        //    return RedirectToAction("Login");
        //}
    }
}
