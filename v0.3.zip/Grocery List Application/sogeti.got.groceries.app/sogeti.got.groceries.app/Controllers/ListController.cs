﻿using sogeti.got.groceries.Business;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace sogeti.got.groceries.app.Controllers
{
    public class ListController : Controller
    {
        private ICategoryManager _categorymanager;
        private IItemManager _itemManager;
        private IListItemManager _listItemManager;
        private IListManager _listManager;

        public ListController()
        {
            _categorymanager = new CategoryManager();
            _itemManager = new ItemManager();
        }

        public ActionResult ShoppingView()
        {
            if (!Request.IsAuthenticated)
                return RedirectToAction("Login", "Users");
            return View();
        }

        public ActionResult CategoryView()
        {
            var categories = _categorymanager.GetAllCategories();
            return View(categories);
        }

        public ActionResult Produce(int categoryid)
        {
            var items = _itemManager.GetItemByCategory(categoryid);
            return View(items);
        }

        public ActionResult Bakery(int categoryid)
        {
            var items = _itemManager.GetItemByCategory(categoryid);
            return View(items);
        }

        public ActionResult ItemList(int categoryid)
        {
            var items = _itemManager.GetItemByCategory(categoryid);
            return View(items);
        }

        public ActionResult AddedItems()
        {
            // list_num = 1;
            //int list_num = _listManager.getListByID()
            //var listItems = _listItemManager.GetListItemByList(list_num);

            return View();
        }

        public ActionResult Snacks()
        {
            return View();
        }


    }
}