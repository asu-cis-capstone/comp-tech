﻿CREATE TABLE [dbo].[Table]
(
	[CategoryId] INT NOT NULL PRIMARY KEY, 
    [CategoryName] VARCHAR(50) NOT NULL
)
