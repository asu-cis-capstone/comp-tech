﻿using System.Data.Entity.ModelConfiguration;
using sogeti.got.groceries.Data.DomainModels;

namespace sogeti.got.groceries.Repository.Mapping
{
    class CategoryMapping : EntityTypeConfiguration<Category>
    {
        public CategoryMapping()
        {
            HasKey(t => t.IdCategory);
            ToTable("Category", "dbo");
        }
    }
}
