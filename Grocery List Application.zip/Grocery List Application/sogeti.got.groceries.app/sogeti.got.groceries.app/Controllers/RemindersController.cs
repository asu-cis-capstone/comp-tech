﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace sogeti.got.groceries.app.Controllers
{
    public class RemindersController : Controller
    {
        // GET: Reminders
        public ActionResult RemindersView()
        {
            if (!Request.IsAuthenticated)
                return RedirectToAction("Login", "Users");

            return View();
        }
    }
}