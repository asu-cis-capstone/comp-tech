﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace sogeti.got.groceries.app.Controllers
{
    public class FavoritesController : Controller
    {
        // GET: Favorites
        public ActionResult FavoritesView()
        {
            return View();
        }
    }
}