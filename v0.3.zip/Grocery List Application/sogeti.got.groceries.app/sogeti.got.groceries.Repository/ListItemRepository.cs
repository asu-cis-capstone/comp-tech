﻿using sogeti.got.groceries.Data.DomainModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sogeti.got.groceries.Repository
{ 

    public interface IListItemRepository
    {
        List<ListItem> GetListItemByList(int lId);
        void AddListItem(ListItem li);
    }
    public class ListItemRepository:IListItemRepository
    {
        private AppDbContext _context;

        public ListItemRepository()
        {
            _context = new AppDbContext();
        }

        public List<ListItem> GetListItemByList(int lId)
        {
            var query = from i in _context.ListItem
                        where i.ListId == lId
                        select i;
            return query.ToList();
        }

        public void AddListItem(ListItem li)
        {
            _context.ListItem.Add(li);
            _context.SaveChanges();
        }
    }
}
