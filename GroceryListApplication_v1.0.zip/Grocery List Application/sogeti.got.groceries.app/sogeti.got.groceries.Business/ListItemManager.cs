﻿using sogeti.got.groceries.Data.DomainModels;
using sogeti.got.groceries.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using sogeti.got.groceries.Data.ViewModels;

namespace sogeti.got.groceries.Business
{
    public interface IListItemManager
    {
        List<ListItemViewModel> GetListItemByList(int lId);
        void AddListItem(ListItem li);
        int FindListItem(ListItem li, int lid);
        void IncreaseQuantity(int id);
        void IncreaseQuantity(ListItem li, int lid);
        void DecreaseQuantity(int id);
        void DeleteListItem(int id);
        void ClearAllItemsInList(int lid);
    }

    public class ListItemManager : IListItemManager
    {
        private IListItemRepository _listitemrepo;

        public ListItemManager()
        {
            _listitemrepo = new ListItemRepository();
        }

        public List<ListItemViewModel> GetListItemByList(int lId)
        {
            var domainModel = _listitemrepo.GetListItemByList(lId);
            var viewmodel = Mapper.Map<List<ListItem>, List<ListItemViewModel>>(domainModel);

            return viewmodel;
        }

        public void AddListItem(ListItem li)
        {
            _listitemrepo.AddListItem(li);
        }
        public int FindListItem(ListItem li, int lid)
        {
            return _listitemrepo.FindListItem(li, lid);
        }
        public void IncreaseQuantity(int id)
        {
            _listitemrepo.IncreaseQuantity(id);
        }
        public void IncreaseQuantity(ListItem li, int lid)
        {
            _listitemrepo.IncreaseQuantity(li, lid);

        }
        public void DecreaseQuantity(int id)
        {
            _listitemrepo.DecreaseQuantity(id);
        }

        public void DeleteListItem(int id)
        {
            _listitemrepo.DeleteListItem(id);
        }

        public void ClearAllItemsInList(int lid)
        {
            _listitemrepo.ClearAllItemsInList(lid);
        }
    }
}
