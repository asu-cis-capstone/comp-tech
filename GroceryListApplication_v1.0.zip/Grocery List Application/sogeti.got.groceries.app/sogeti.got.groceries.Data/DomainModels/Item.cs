﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sogeti.got.groceries.Data.DomainModels
{
    public class Item
    {
        public int IdItem { get; set; }
        public int IdCategory { get; set; }
        public string ItemName { get; set; }
        public string ImgPath { get; set; }


        public virtual Category Category { get; set; }
        public virtual ICollection<ListItem> ListItems { get; set; }
    }
}
