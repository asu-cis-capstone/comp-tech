﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(sogeti.got.groceries.app.Startup))]
namespace sogeti.got.groceries.app
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
