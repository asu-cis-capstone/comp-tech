﻿using Sogeti.Got.Groceries.Business;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Sogeti.Got.Groceries.Controllers
{
    public class UserController : Controller
    {
        private IUserManager _userManager;

        public UserController()
        {
            _userManager = new UserManager();
        }

        // GET: User
        public ActionResult ShowUsers()
        {
            var users = _userManager.GetAllUsers();
            return View(users);
        }
    }
}