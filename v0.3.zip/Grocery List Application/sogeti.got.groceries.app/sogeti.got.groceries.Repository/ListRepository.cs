﻿using sogeti.got.groceries.Data.DomainModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sogeti.got.groceries.Repository
{
    public interface IListRepository
    {
        void addList(List l);
        List<List> getListByID(int uID);
    }
    public class ListRepository:IListRepository
    {
        private AppDbContext _context;

        public ListRepository()
        {
            _context = new AppDbContext();
        }

        public void addList(List l)
        {
            _context.List.Add(l);
            _context.SaveChanges();
        }

        public List<List> getListByID(int uID)
        {
            var query = from i in _context.List
                        where i.UserId == uID
                        select i;
            return query.ToList();
        }

    }
}
