﻿using sogeti.got.groceries.Data.DomainModels;
using sogeti.got.groceries.Data.ViewModels;
using sogeti.got.groceries.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;

namespace sogeti.got.groceries.Business
{
    public interface IListManager
    {
        void addList(List l);
        List<ListViewModel> getListByID(int uID);
    }
        public class ListManager : IListManager
        {
            private IListRepository _listrepo;

            public ListManager()
            {
                _listrepo = new ListRepository();
            }

            public void addList(List l)
            {
                _listrepo.addList(l);
            }

            public List<ListViewModel> getListByID(int uid)
            {
                var domainModel = _listrepo.getListByID(uid);
                var viewmodel = Mapper.Map<List<List>, List<ListViewModel>>(domainModel);

                return viewmodel;
            }
        }
}
