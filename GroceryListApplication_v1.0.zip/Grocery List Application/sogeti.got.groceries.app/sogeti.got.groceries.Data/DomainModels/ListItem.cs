﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sogeti.got.groceries.Data.DomainModels
{
    public class ListItem
    {
        public int Id { get; set; }
        public int ItemID { get; set; }
        public int ListID { get; set; }
        public int Quantity { get; set; }


        public virtual Item Item { get; set; }
        public virtual List List { get; set; }
    }
}
