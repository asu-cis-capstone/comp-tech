﻿using sogeti.got.groceries.Data.DomainModels;
using System.Data.Entity.ModelConfiguration;

namespace sogeti.got.groceries.Repository.Mapping
{
    class ItemMapping : EntityTypeConfiguration<Item>
    {
        public ItemMapping()
        {
            HasKey(t => t.IdItem);

            ToTable("Item", "dbo");

            HasRequired(t => t.Category)
                .WithMany(t => t.Items)
                .HasForeignKey(t => t.IdCategory);
        }
    }
}
