﻿using Sogeti.Got.Groceries.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Sogeti.Got.Groceries.Data.ViewModels;
using Sogeti.Got.Groceries.Data.DomainModels;
using AutoMapper;

namespace Sogeti.Got.Groceries.Business
{
    public interface IItemManager
    {
        List<ItemViewModel> GetAllItems();
    }

    public class ItemManager : IItemManager
    {
        private IItemRepository _itemRepo;

        public ItemManager()
        {
            _itemRepo = new ItemRepository();
        }

        public List<ItemViewModel> GetAllItems()
        {
            var domainModel = _itemRepo.GetAllItems();
            //Mapper.CreateMap<Item,ItemViewModel>();
            var viewModel = Mapper.Map<List<Item>, List<ItemViewModel>>(domainModel);

            return viewModel;
        }
    }
}
