﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sogeti.got.groceries.Data.ViewModels
{
    public class CategoryViewModel
    {
        public int IdCategory { get; set; }
        public string CategoryName { get; set; }
        public string ImgPath { get; set; }

        public virtual List<DomainModels.Item> Items { get; set; }
    }
}
