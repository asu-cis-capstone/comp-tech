﻿using sogeti.got.groceries.Data.DomainModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sogeti.got.groceries.Repository
{
    public interface IUserRepository
    {
        List<Users> GetAllItems();
        //List<User> GetAllUsers();
        //User GetUserById(int itemId);
        void AddUser(Users u);
        //void DeleteUser(int itemId);
        //void UpdateUser(Users u);
        //void Login(Users u);
    }

    public class UserRepository : IUserRepository
    {
        private AppDbContext db;

        public UserRepository()
        {
            db = new AppDbContext();
        }

        public void AddUser(Users u)
        {
            try
            {
                db.Users.Add(u);
                db.SaveChanges();
            }
            catch (Exception e)
            {

                e.Message.ToString();
            }
        }

        public List<Users> GetAllItems()
        {

            var query = from i in db.Users
                        select i;
            return query.ToList();

        }
    }
}
