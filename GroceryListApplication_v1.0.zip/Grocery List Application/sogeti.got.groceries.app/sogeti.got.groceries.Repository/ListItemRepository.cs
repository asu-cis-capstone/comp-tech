﻿using sogeti.got.groceries.Data.DomainModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Linq;

namespace sogeti.got.groceries.Repository
{ 

    public interface IListItemRepository
    {
        List<ListItem> GetListItemByList(int lId);
        void AddListItem(ListItem li);
        int FindListItem(ListItem li, int lid);
        void IncreaseQuantity(int id);
        void IncreaseQuantity(ListItem li, int lid);
        void DecreaseQuantity(int id);
        void DeleteListItem(int id);
        void ClearAllItemsInList(int lid);
    }
    public class ListItemRepository : IListItemRepository
    {
        private AppDbContext _context;

        public ListItemRepository()
        {
            _context = new AppDbContext();
        }

        public List<ListItem> GetListItemByList(int lId)
        {
            var query = from i in _context.ListItem
                        where i.ListID == lId
                        select i;
            return query.ToList();
        }

        public void AddListItem(ListItem li)
        {
            var query = from i in _context.ListItem
                        select i;
            foreach(ListItem item in query)
            {
                if(item.ItemID == li.ItemID)
                {
                    if (item.ListID == li.ListID)
                        return;
                }
            }
            try
            {
                _context.ListItem.Add(li);
                _context.SaveChanges();
            }
            catch (Exception ex)
            {

                ex.Message.ToString();
            }

        }

        public int FindListItem(ListItem li, int lid)
        {
            try
            {
                int index = -1;
                List<ListItem> lItem = GetListItemByList(lid);
                if (lItem != null)
                {
                    for (int i = 0; i < lItem.Count; i++)
                    {
                        if (lItem[i].Equals(li))
                            index = i;
                    }
                }
                return index;

            }
            catch (Exception)
            {
                throw;
            }
        }
        public void IncreaseQuantity(int id)
        {
            var query = from i in _context.ListItem
                        where i.Id == id
                        select i;
            foreach (ListItem item in query)
            {
                item.Quantity++;
            }
            _context.SaveChanges();
        }
        public void IncreaseQuantity(ListItem li, int lid)
        {
            int index = FindListItem(li, lid);
            if (index != -1)
            {
                List<ListItem> liList = GetListItemByList(lid);
                liList[index].Quantity++;
            }
        }
        public void DecreaseQuantity(int id)
        {
            var query = from i in _context.ListItem
                        where i.Id == id
                        select i;
            foreach (ListItem item in query)
            {
                if (item.Quantity > 1)
                    item.Quantity--;
                else if (item.Quantity == 1)
                    _context.ListItem.Remove(item);
            }
            _context.SaveChanges();
        }

        public void DeleteListItem(int id)
        {
            var query = from i in _context.ListItem
                        where i.Id == id
                        select i;


            foreach (ListItem item in query)
            {
                _context.ListItem.Remove(item);

            }

            //var liRemove = _context.ListItem.SingleOrDefault(x => x.Id == id);

            //_context.ListItem.Remove(liRemove);

            _context.SaveChanges();
        }
        public void ClearAllItemsInList(int lid)
        {
            var query = from i in _context.ListItem
                        where i.ListID == lid
                        select i;

            foreach (ListItem items in query)
            {
                _context.ListItem.Remove(items);
            }
            _context.SaveChanges();
        }


    }
}
