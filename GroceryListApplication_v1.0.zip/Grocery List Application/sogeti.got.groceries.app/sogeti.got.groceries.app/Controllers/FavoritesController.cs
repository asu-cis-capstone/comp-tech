﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using sogeti.got.groceries.Data.ViewModels;
using sogeti.got.groceries.Repository;
using sogeti.got.groceries.Business;

namespace sogeti.got.groceries.app.Controllers
{
    public class FavoritesController : Controller
    {
        private IListItemManager _listItemManager;
        private IListManager _listManager;

        public FavoritesController()
        {
            _listItemManager = new ListItemManager();
            _listManager = new ListManager();
        }
        // GET: Favorites
        public ActionResult FavoritesView()
        {
            if (!Request.IsAuthenticated)
                return RedirectToAction("Login", "Users");
            if (Session["uid"] == null)
                return RedirectToAction("Login", "Users");

            var favList = _listManager.getFavoritesList(Convert.ToInt32(Session["uid"].ToString()));

            return View(favList);
        }
    }
}