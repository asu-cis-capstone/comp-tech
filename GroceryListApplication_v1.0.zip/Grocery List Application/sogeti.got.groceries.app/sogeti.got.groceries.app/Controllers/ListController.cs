﻿using sogeti.got.groceries.Business;
using sogeti.got.groceries.Data.DomainModels;
using sogeti.got.groceries.Data.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace sogeti.got.groceries.app.Controllers
{
    public class ListController : Controller
    {
        private ICategoryManager _categorymanager;
        private IItemManager _itemManager;
        private IListItemManager _listItemManager;
        private IListManager _listManager;

        public ListController()
        {
            _categorymanager = new CategoryManager();
            _itemManager = new ItemManager();
            _listItemManager = new ListItemManager();
            _listManager = new ListManager();
        }

        public ActionResult ShoppingView()
        {
            if (!Request.IsAuthenticated)
                return RedirectToAction("Login", "Users");

            if (Session["uid"] == null)
                return RedirectToAction("Login", "Users");


            var shoppinglist = _listManager.getShoppingList(Convert.ToInt32(Session["uid"].ToString()));
            return View(shoppinglist);
        }


        public ActionResult ItemView(int categoryid)
        {
            var items = _itemManager.GetItemByCategory(categoryid);
            var model = new AddItemViewModel
            {
                items = items,
                categoryId = categoryid
            };
            return View(model);
        }

        public ActionResult AddItem(int categoryId, int itemid)
        {
            var mylist = _listManager.getListByID(Convert.ToInt32(Session["uid"].ToString()));
            ListItem li = new ListItem();
            li.ItemID = itemid;
            li.ListID = Convert.ToInt32(Session["listid"]);
            li.Quantity = 1;
            _listItemManager.AddListItem(li);
            var items = _itemManager.GetItemByCategory(categoryId);
            var model = new AddItemViewModel
            {
                items = items,
                categoryId = categoryId
            };
            return View("ItemView",model);

        }

        public ActionResult CategoryView(int listid)
        {
            Session["listid"] = null;
            Session["listid"] = listid;
            var categories = _categorymanager.GetAllCategories();
            return View(categories);
        }

        public ActionResult Produce(int categoryid)
        {
            var items = _itemManager.GetItemByCategory(categoryid);
            return View(items);
        }

        public ActionResult Bakery(int categoryid)
        {
            var items = _itemManager.GetItemByCategory(categoryid);
            return View(items);
        }

        public ActionResult ItemList(int categoryid)
        {
            var items = _itemManager.GetItemByCategory(categoryid);
            return View(items);
        }

        public ActionResult AddedItems(ListItem li)
        {
            // list_num = 1;
            //int list_num = _listManager.getListByID()
            //var listItems = _listItemManager.GetListItemByList(list_num);
            _listItemManager.AddListItem(li);

            return View();
        }

        [HttpGet]
        public ActionResult GenerateTypeOfList()
        {
            return View();
        }

        [HttpPost]
        public ActionResult GenerateTypeOfList(List myList)
        {
            if (ModelState.IsValid)
            {
                //you should check duplicate registration here 
                myList.UserID = Convert.ToInt32(@Session["uid"]);
                myList.ListName += "- @";
                myList.ListName += Request["list"].ToString();
                _listManager.addList(myList);
                ModelState.Clear();

                //ViewBag.Message = "Successfully Registration Done";
                return RedirectToAction("ShoppingView", "List");

            }


            return View();
        }


        public ActionResult Snacks()
        {
            return View();
        }

        public ActionResult DisplayList(int listId)
        {
            Session["listid"] = listId;
            List<ListItemViewModel> listItems = _listItemManager.GetListItemByList(listId);
            List<int> itemID = new List<int>();
            List<string> imgpath = new List<string>();
            List<string> names = new List<string>();

            for (int i = 0; i < listItems.Count; i++)
                itemID.Add(listItems[i].ItemId);
            for (int i = 0; i < itemID.Count; i++)
            {
                imgpath.Add(_itemManager.GetImgPath(itemID[i]));
                names.Add(_itemManager.GetName(itemID[i]));
            }

            List<ListItemAddedViewModel> modelList = new List<ListItemAddedViewModel>();
            ListItemAddedViewModel model = new ListItemAddedViewModel();

            for (int i = 0; i < listItems.Count; i++)
            {
                model = new ListItemAddedViewModel();
                model.liId = listItems[i].Id;
                model.listItems = listItems[i];
                model.imgPath = imgpath[i];
                model.name = names[i];

                modelList.Add(model);
            }

            return View(modelList);
        }


        public ActionResult DisplayFavList(int listId)
        {
            Session["listid"] = listId;
            List<ListItemViewModel> listItems = _listItemManager.GetListItemByList(listId);
            List<int> itemID = new List<int>();
            List<string> imgpath = new List<string>();
            List<string> names = new List<string>();

            for (int i = 0; i < listItems.Count; i++)
                itemID.Add(listItems[i].ItemId);
            for (int i = 0; i < itemID.Count; i++)
            {
                imgpath.Add(_itemManager.GetImgPath(itemID[i]));
                names.Add(_itemManager.GetName(itemID[i]));
            }

            List<ListItemAddedViewModel> modelList = new List<ListItemAddedViewModel>();
            ListItemAddedViewModel model = new ListItemAddedViewModel();

            for (int i = 0; i < listItems.Count; i++)
            {
                model = new ListItemAddedViewModel();
                model.liId = listItems[i].Id;
                model.listItems = listItems[i];
                model.imgPath = imgpath[i];
                model.name = names[i];

                modelList.Add(model);
            }

            return View(modelList);
        }

        public ActionResult IncreaseQuantity(int id)
        {
            _listItemManager.IncreaseQuantity(id);
            return RedirectToAction("DisplayList", new { listId = Convert.ToInt32(Session["listid"]) });
        }

        public ActionResult DecreaseQuantity(int id)
        {
            _listItemManager.DecreaseQuantity(id);
            return RedirectToAction("DisplayList", new { listId = Convert.ToInt32(Session["listid"]) });
        }

        public ActionResult DeleteList(int id)
        {
            _listItemManager.ClearAllItemsInList(id);
            _listManager.DeleteList(id);
            //return RedirectToAction("ShoppingView");
            return Redirect(Request.UrlReferrer.ToString());
        }

        public ActionResult DeleteListItem(int itemId)
        {
            _listItemManager.DeleteListItem(itemId);
            return RedirectToAction("DisplayList", new { listId = Convert.ToInt32(Session["listid"]) });
        }

        public ActionResult MakeFavoritesList(int lid)
        {
            _listManager.MakeFavorites(lid);
            return RedirectToAction("ShoppingView");
        }
    }
}