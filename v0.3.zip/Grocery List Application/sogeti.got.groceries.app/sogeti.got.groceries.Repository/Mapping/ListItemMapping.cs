﻿using sogeti.got.groceries.Data.DomainModels;
using System;
using System.Collections.Generic;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sogeti.got.groceries.Repository.Mapping
{
    class ListItemMapping: EntityTypeConfiguration<ListItem>
    {
        public ListItemMapping()
        {
            HasKey(t => t.Id);
            ToTable("ListItem", "dbo");
        }
    }
}
