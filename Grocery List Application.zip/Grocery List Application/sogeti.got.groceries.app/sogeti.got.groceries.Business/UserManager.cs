﻿using sogeti.got.groceries.Data.DomainModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using sogeti.got.groceries.Repository;
using sogeti.got.groceries.Data.ViewModels;
using AutoMapper;

namespace sogeti.got.groceries.Business
{
    public interface IUserManager
    {
        List<UserViewModel> GetAllItems();
        void AddUser(Users u);
        bool Login(UserViewModel u);
        bool IsValid(string userName, string password);
        int returnUID();
    }
    public class UserManager : IUserManager
    {
        private IUserRepository _userRepo;
        private int session_uid;

        public UserManager()
        {
            _userRepo = new UserRepository();
        }

        public int returnUID()
        {
            return session_uid;
        }


        public void AddUser(Users u)
        {
            _userRepo.AddUser(u);
        }

        public List<UserViewModel> GetAllItems()
        {
            var domainModel = _userRepo.GetAllItems();
            var viewModel = Mapper.Map<List<Users>, List<UserViewModel>>(domainModel);

            return viewModel;
        }

        public bool Login(UserViewModel u)
        {
            return IsValid(u.UserName, u.Password);
        }

        public bool IsValid(string userName, string password)
        {
            bool IsValid = false;

            using (var db = new Repository.AppDbContext())

            {
                var user = db.Users.FirstOrDefault(u => u.UserName == userName);

                if (user != null)
                {
                    if (user.Password == password)
                    {
                        session_uid = user.Id;
                        IsValid = true;
                    }
                }
            }
            return IsValid;
        }
    }
}
