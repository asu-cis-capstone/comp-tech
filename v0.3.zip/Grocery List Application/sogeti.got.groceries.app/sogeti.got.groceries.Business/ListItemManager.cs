﻿using sogeti.got.groceries.Data.DomainModels;
using sogeti.got.groceries.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using sogeti.got.groceries.Data.ViewModels;

namespace sogeti.got.groceries.Business
{
    public interface IListItemManager
    {
        List<ListItemViewModel> GetListItemByList(int lId);
        void AddListItem(ListItem li);
    }

    public class ListItemManager : IListItemManager
    {
        private IListItemRepository _listitemrepo;

        public ListItemManager()
        {
            _listitemrepo = new ListItemRepository();
        }

        public List<ListItemViewModel> GetListItemByList(int lId)
        {
            var domainModel = _listitemrepo.GetListItemByList(lId);
            var viewmodel = Mapper.Map<List<ListItem>, List<ListItemViewModel>>(domainModel);

            return viewmodel;
        }

        public void AddListItem(ListItem li)
        {
            _listitemrepo.AddListItem(li);
        }

    }
}
