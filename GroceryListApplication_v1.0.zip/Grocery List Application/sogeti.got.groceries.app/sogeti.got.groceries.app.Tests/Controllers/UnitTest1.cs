﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using sogeti.got.groceries.app.Controllers;
using sogeti.got.groceries.Data.ViewModels;
using sogeti.got.groceries.app;
using System.Web.Mvc;

namespace sogeti.got.groceries.app.Tests.Controllers
{
    [TestClass]
    public class UnitTest1
    {
        //[TestMethod]
        //public void LogOnTest1()
        //{
        //    UsersController controller = new UsersController();

        //    UserViewModel user = new UserViewModel();
        //    user.UserName = "john480";
        //    user.Password = "abc123";
        //    user.ConfirmPassword = user.Password;
        //    user.FirstName = "john";
        //    user.LastName = "smith";
        //    user.Email = "johnsmith@aol.com";
        //    user.Id = 12;
        //    user.RegDate = new DateTime.Now();
        //    //var result = (ViewResult)controller.LogIn(user);
        //    var result = controller.LogIn(user);
        //    //Assert.AreEqual("Login",result.ViewName);
        //    Assert.IsNotNull(result);
        //}
    }
}
