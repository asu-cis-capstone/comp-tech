﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sogeti.got.groceries.Data.ViewModels
{
    public class ListItemAddedViewModel
    {
        public int liId { get; set; }
        public ListItemViewModel listItems { get; set; }
        public string imgPath { get; set; }
        public string name { get; set; }
    }
}
