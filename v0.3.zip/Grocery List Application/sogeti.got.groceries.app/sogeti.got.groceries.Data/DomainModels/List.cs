﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sogeti.got.groceries.Data.DomainModels
{
    public class List
    {
        public int ListId { get; set; }
        public string ListName { get; set; }
        public int UserId { get; set; }

        //public virtual List<Users> User { get; set; }
    }
}
