﻿using sogeti.got.groceries.Data.DomainModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sogeti.got.groceries.Repository
{
    public interface ICategoryRepository
    {
        List<Category> GetAllCategories();
    }
    public class CategoryRepository : ICategoryRepository
    {
        private readonly AppDbContext _context;

        public CategoryRepository()
        {
            _context = new AppDbContext();
        }

        public List<Category> GetAllCategories()
        { 
            var query = from i in _context.Categories orderby i.CategoryName ascending
                        select i ;
            return query.ToList();
        }

    }
}
