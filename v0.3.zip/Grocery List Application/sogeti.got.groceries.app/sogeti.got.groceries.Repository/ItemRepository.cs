﻿using sogeti.got.groceries.Data.DomainModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sogeti.got.groceries.Repository
{
    public interface IItemRepository
    {
        List<Item> GetAllItems();
       Item GetItemById(int itemId);
        void AddItem(Item item);
        void DeleteItem(int itemId);
        void UpdateItem(Item item);
        List<Item> GetItemByCategory(int CategoryId);
    }

    public class ItemRepository : IItemRepository
    {
        private readonly AppDbContext _context;

        public ItemRepository()
        {
            _context = new AppDbContext();
        }

        public List<Item> GetAllItems()
        {
            var query = from i in _context.Items
                        select i;

            return query.ToList();
        }

        public Item GetItemById(int itemId)
        {
            var query = from i in _context.Items
                        where i.IdItem == itemId
                        select i;

            return query.FirstOrDefault();
        }

        public void AddItem(Item item)
        {
            _context.Items.Add(item);

            _context.SaveChanges();
        }

        public void DeleteItem(int itemId)
        {
            var item = GetItemById(itemId);

            _context.Items.Remove(item);

            _context.SaveChanges();
        }

        public void UpdateItem(Item item)
        {
            var i = GetItemById(item.IdItem);

            i.ItemName = item.ItemName;
            i.IdCategory = item.IdCategory;

            _context.SaveChanges();
        }

        public List<Item> GetItemByCategory(int CategoryId)
        {
            var query = from i in _context.Items
                        where i.IdCategory == CategoryId
                        select i;
            return query.ToList();
        }

    }
}
