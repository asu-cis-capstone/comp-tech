﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;


namespace sogeti.got.groceries.Repository
{
    class ShoppingListCartRepository
    {
        //private AppDbContext _context;
        //private string ShoppingListCartID { get; set; }


        //public ShoppingListCartRepository(AppDbContext context)
        //{
        //    _context = context;
        //}

        //public static ShoppingListCartRepository GetCart(AppDbContext db, HttpRequest context)
        //{
        //    var cart = new ShoppingListCartRepository(db);
        //    cart.ShoppingListCartID = cart.GetCartId(context);
        //    return cart;
        //}

    }
}
