﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using sogeti.got.groceries.Data.DomainModels;
using System.Data.Entity.ModelConfiguration;

namespace sogeti.got.groceries.Repository.Mapping
{
    class UserMapping : EntityTypeConfiguration<Users>
    {
        public UserMapping()
        {
            HasKey(t => t.Id);
            ToTable("Users", "dbo");

        }
    }
}
