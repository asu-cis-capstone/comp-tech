﻿using System.Data.Entity.ModelConfiguration;
using Sogeti.Got.Groceries.Data.DomainModels;

namespace Gogeti.Got.Groceries.Repository.Mapping
{
    class CategoryMapping : EntityTypeConfiguration<Category>
    {
        public CategoryMapping()
        {
            HasKey(t => t.IdCategory);
            ToTable("Category", "dbo");
        }
    }
}
