﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using Sogeti.Got.Groceries.Data.DomainModels;
using Sogeti.Got.Groceries.Data.ViewModels;

namespace Sogeti.Got.Groceries.Business
{
    public static class ModelMapping
    {
        public static void ConfigureMaps()
        {
            Mapper.CreateMap<Item, ItemViewModel>()
                .ForMember(dest => dest.Id, opt => opt.MapFrom(src => (src.IdItem)))
                .ForMember(dest => dest.Name, opt => opt.MapFrom(src => (src.ItemName)))
                .ForMember(dest => dest.Category, opt => opt.MapFrom(src => (src.Category.CategoryName)));

            Mapper.CreateMap<Users, UserViewModel>()
                .ForMember(dest => dest.Id, opt => opt.MapFrom(src => (src.Id)))
                .ForMember(dest => dest.UserName, opt => opt.MapFrom(src => (src.UserName)))
                .ForMember(dest => dest.Password, opt => opt.MapFrom(src => (src.Password)))
                .ForMember(dest => dest.ConfirmPassword, opt => opt.MapFrom(src => (src.ConfirmPassword)))
                .ForMember(dest => dest.Email, opt => opt.MapFrom(src => (src.Email)))
                .ForMember(dest => dest.RegDate, opt => opt.MapFrom(src => (src.RegDate)))
                .ForMember(dest => dest.FirstName, opt => opt.MapFrom(src => (src.FirstName)))
                .ForMember(dest => dest.LastName, opt => opt.MapFrom(src => (src.LastName)));
        }
    }
}
