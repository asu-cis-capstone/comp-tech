﻿using sogeti.got.groceries.Data.DomainModels;
using sogeti.got.groceries.Data.ViewModels;
using sogeti.got.groceries.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;

namespace sogeti.got.groceries.Business
{
    public interface ICategoryManager
    {
        List<CategoryViewModel> GetAllCategories();
    }

    public class CategoryManager : ICategoryManager
    {
        private ICategoryRepository _categoryRepo;

        public CategoryManager()
        {
            _categoryRepo = new CategoryRepository();
        }

        public List<CategoryViewModel> GetAllCategories()
        {
            var domainModel = _categoryRepo.GetAllCategories();
            var viewModel = Mapper.Map<List<Category>, List<CategoryViewModel>>(domainModel);

            return viewModel;
        }


    }
}
