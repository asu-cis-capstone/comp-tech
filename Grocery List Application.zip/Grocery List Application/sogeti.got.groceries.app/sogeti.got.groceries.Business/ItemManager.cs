﻿using sogeti.got.groceries.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using sogeti.got.groceries.Data.ViewModels;
using sogeti.got.groceries.Data.DomainModels;
using AutoMapper;

namespace sogeti.got.groceries.Business
{
    public interface IItemManager
    {
        List<ItemViewModel> GetAllItems();
        List<ItemViewModel> GetItemByCategory(int categoryid);
        string GetImgPath(int ItemId);
    }

    public class ItemManager : IItemManager
    {
        private IItemRepository _itemRepo;

        public ItemManager()
        {
            _itemRepo = new ItemRepository();
        }

        public List<ItemViewModel> GetAllItems()
        {
            var domainModel = _itemRepo.GetAllItems();
            var viewModel = Mapper.Map<List<Item>, List<ItemViewModel>>(domainModel);

            return viewModel;
        }

        public List<ItemViewModel> GetItemByCategory(int categoryid )
        {
            var domainModel = _itemRepo.GetItemByCategory(categoryid);
            var viewModel = Mapper.Map<List<Item>, List<ItemViewModel>>(domainModel);

            return viewModel;
        }

        public string GetImgPath(int ItemId)
        {
            string path = _itemRepo.GetImgPath(ItemId);
            return path;
        }

    }
}
