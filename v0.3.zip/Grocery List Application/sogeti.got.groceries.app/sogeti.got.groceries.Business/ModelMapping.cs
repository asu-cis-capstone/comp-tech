﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using sogeti.got.groceries.Data.DomainModels;
using sogeti.got.groceries.Data.ViewModels;

namespace sogeti.got.groceries.Business
{
    public static class ModelMapping
    {
        public static void ConfigureMaps()
        {
            Mapper.CreateMap<Users, UserViewModel>()
                .ForMember(dest => dest.Id, opt => opt.MapFrom(src => (src.Id)))
                .ForMember(dest => dest.UserName, opt => opt.MapFrom(src => (src.UserName)))
                .ForMember(dest => dest.Password, opt => opt.MapFrom(src => (src.Password)))
                .ForMember(dest => dest.Email, opt => opt.MapFrom(src => (src.Email)))
                .ForMember(dest => dest.RegDate, opt => opt.MapFrom(src => (src.RegDate)))
                .ForMember(dest => dest.FirstName, opt => opt.MapFrom(src => (src.FirstName)))
                .ForMember(dest => dest.LastName, opt => opt.MapFrom(src => (src.LastName)));

            Mapper.CreateMap<Item, ItemViewModel>()
                .ForMember(dest => dest.Id, opt => opt.MapFrom(src => (src.IdItem)))
                .ForMember(dest => dest.Name, opt => opt.MapFrom(src => (src.ItemName)))
                .ForMember(dest => dest.Category, opt => opt.MapFrom(src => (src.Category.CategoryName)));

            Mapper.CreateMap<Category, CategoryViewModel>()
                .ForMember(dest => dest.IdCategory, opt => opt.MapFrom(src => (src.IdCategory)))
                .ForMember(dest => dest.CategoryName, opt => opt.MapFrom(src => (src.CategoryName)))
                .ForMember(dest => dest.Items, opt=>opt.MapFrom(src =>(src.Items)))
                .ForMember(dest => dest.ImgPath, opt=>opt.MapFrom(src =>(src.ImgPath)));

            Mapper.CreateMap<List, ListViewModel>()
                .ForMember(dest => dest.ListId, opt => opt.MapFrom(src => (src.ListId)))
                .ForMember(dest => dest.ListName, opt => opt.MapFrom(src => (src.ListName)))
                .ForMember(dest => dest.UserId, opt => opt.MapFrom(src => (src.UserId)));

            Mapper.CreateMap<ListItem, ListItemViewModel>()
                .ForMember(dest => dest.Id, opt => opt.MapFrom(src => (src.ListId)))
                .ForMember(dest => dest.ListId, opt => opt.MapFrom(src => (src.ListId)))
                .ForMember(dest => dest.ItemId, opt => opt.MapFrom(src => (src.ItemId)))
                .ForMember(dest => dest.Quantity, opt => opt.MapFrom(src => (src.Quantity)));

        }
    }
}
