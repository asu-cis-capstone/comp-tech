﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Sogeti.Got.Groceries.Startup))]
namespace Sogeti.Got.Groceries
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
