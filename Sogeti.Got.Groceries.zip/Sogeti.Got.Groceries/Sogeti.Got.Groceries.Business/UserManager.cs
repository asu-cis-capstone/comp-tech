﻿using Sogeti.Got.Groceries.Data.DomainModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Sogeti.Got.Groceries.Repository;
using Sogeti.Got.Groceries.Data.ViewModels;
using AutoMapper;

namespace Sogeti.Got.Groceries.Business
{
    public interface IUserManager
    {
        List<UserViewModel> GetAllUsers();
        void AddUser(Users u);
    }
    public class UserManager : IUserManager
    {
        private IUserRepository _userRepo;

        public UserManager()
        {
            _userRepo = new UserRepository();
        }

        public void AddUser(Users u)
        {
            _userRepo.AddUser(u);
        }

        public List<UserViewModel> GetAllUsers()
        {
            var domainModel = _userRepo.GetAllUsers();
            var viewModel = Mapper.Map<List<Users>, List<UserViewModel>>(domainModel);

            return viewModel;
        }

    }
}
