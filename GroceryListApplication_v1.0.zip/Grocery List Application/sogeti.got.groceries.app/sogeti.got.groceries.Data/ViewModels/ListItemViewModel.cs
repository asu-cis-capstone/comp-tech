﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sogeti.got.groceries.Data.ViewModels
{
    public class ListItemViewModel
    {
        public int Id { get; set; }
        public int ItemId { get; set; }
        public int ListId { get; set; }
        public int Quantity { get; set; }

        //public virtual List<DomainModels.Item> Item { get; set; }
        //public virtual List<DomainModels.List> List { get; set; }
    }
}
