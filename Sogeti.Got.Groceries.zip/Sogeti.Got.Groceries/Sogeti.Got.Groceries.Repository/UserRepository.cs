﻿using Sogeti.Got.Groceries.Data.DomainModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sogeti.Got.Groceries.Repository
{
    public interface IUserRepository
    {
        List<Users> GetAllUsers();
        //User GetUserById(int itemId);
        void AddUser(Users u);
        //void DeleteUser(int itemId);
        //void UpdateUser(Item item);
    }


    public class UserRepository : IUserRepository
    {
        private readonly AppDbContext _context;

        public UserRepository()
        {
            _context = new AppDbContext();
        }

        public List<Users> GetAllUsers()
        {
            var query = from i in _context.Users
                        select i;
            return query.ToList();
        }

        public void AddUser(Users u)
        {
            _context.Users.Add(u);
            _context.SaveChanges();
        }



    }
}
