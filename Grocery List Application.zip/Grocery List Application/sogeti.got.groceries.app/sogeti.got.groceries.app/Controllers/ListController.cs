﻿using sogeti.got.groceries.Business;
using sogeti.got.groceries.Data.DomainModels;
using sogeti.got.groceries.Data.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace sogeti.got.groceries.app.Controllers
{
    public class ListController : Controller
    {
        private ICategoryManager _categorymanager;
        private IItemManager _itemManager;
        private IListItemManager _listItemManager;
        private IListManager _listManager;

        public ListController()
        {
            _categorymanager = new CategoryManager();
            _itemManager = new ItemManager();
            _listItemManager = new ListItemManager();
            _listManager = new ListManager();
        }

        public ActionResult ShoppingView()
        {
            if (!Request.IsAuthenticated)
                return RedirectToAction("Login", "Users");

            var shoppinglist = _listManager.getShoppingList(Convert.ToInt32(Session["uid"].ToString()));
            return View(shoppinglist);
        }


        public ActionResult ItemView(int categoryid)
        {
            var items = _itemManager.GetItemByCategory(categoryid);
            var model = new AddItemViewModel
            {
                items = items,
                categoryId = categoryid
            };
            return View(model);
        }

        public ActionResult AddItem(int categoryId, int itemid)
        {
            var mylist = _listManager.getListByID(Convert.ToInt32(Session["uid"].ToString()));
            ListItem li = new ListItem();
            li.ItemID = itemid;
            li.ListID = mylist[0].ListId;
            li.Quantity = 0;
            _listItemManager.AddListItem(li);
            var items = _itemManager.GetItemByCategory(categoryId);
            var model = new AddItemViewModel
            {
                items = items,
                categoryId = categoryId
            };
            return View("ItemView",model);

        }

        public ActionResult CategoryView()
        {
            var categories = _categorymanager.GetAllCategories();
            return View(categories);
        }

        public ActionResult Produce(int categoryid)
        {
            var items = _itemManager.GetItemByCategory(categoryid);
            return View(items);
        }

        public ActionResult Bakery(int categoryid)
        {
            var items = _itemManager.GetItemByCategory(categoryid);
            return View(items);
        }

        public ActionResult ItemList(int categoryid)
        {
            var items = _itemManager.GetItemByCategory(categoryid);
            return View(items);
        }

        public ActionResult AddedItems(ListItem li)
        {
            // list_num = 1;
            //int list_num = _listManager.getListByID()
            //var listItems = _listItemManager.GetListItemByList(list_num);
            _listItemManager.AddListItem(li);

            return View();
        }

        [HttpGet]
        public ActionResult GenerateTypeOfList()
        {
            return View();
        }

        [HttpPost]
        public ActionResult GenerateTypeOfList(List myList)
        {
            if (ModelState.IsValid)
            {
                //you should check duplicate registration here 
                myList.UserID = Convert.ToInt32(@Session["uid"]);
                myList.ListName += "- @";
                myList.ListName += Request["list"].ToString();
                _listManager.addList(myList);
                ModelState.Clear();

                //ViewBag.Message = "Successfully Registration Done";
                return RedirectToAction("ShoppingView", "List");

            }


            return View();
        }


        public ActionResult Snacks()
        {
            return View();
        }

        public ActionResult DisplayList(int listId)
        {
            List<ListItemViewModel> listItems = _listItemManager.GetListItemByList(listId);
            List<int> itemID = new List<int>();
            List<string> imgpath = new List<string>();

            for (int i = 0; i < listItems.Count; i++)
                itemID.Add(listItems[i].ItemId);
            for (int i = 0; i < itemID.Count; i++)
                imgpath.Add(_itemManager.GetImgPath(itemID[i]));

            return View(imgpath);
        }

    }
}