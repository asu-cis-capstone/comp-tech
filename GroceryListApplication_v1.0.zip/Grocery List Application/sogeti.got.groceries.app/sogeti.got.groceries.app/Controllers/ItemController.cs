﻿using sogeti.got.groceries.Business;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace sogeti.got.groceries.app.Controllers
{
    public class ItemController : Controller
    {
        private IItemManager _itemManager;

        public ItemController()
        {
            _itemManager = new ItemManager();
        }




        public ActionResult ShowItems()
        {
            var items = _itemManager.GetAllItems();

            return View(items);
        }


    }
}