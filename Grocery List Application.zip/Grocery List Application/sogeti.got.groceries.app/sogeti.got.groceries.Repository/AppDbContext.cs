﻿using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.Data.Entity.Infrastructure;
using sogeti.got.groceries.Data.DomainModels;
using sogeti.got.groceries.Repository.Mapping;

namespace sogeti.got.groceries.Repository
{
    public class AppDbContext : DbContext
    {
        public AppDbContext()
            : base("name=GroceryListEntities")
        {
            Database.SetInitializer<AppDbContext>(null);
        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();

            modelBuilder.Configurations.Add(new CategoryMapping());
            modelBuilder.Configurations.Add(new ItemMapping());
            modelBuilder.Configurations.Add(new UserMapping());
            modelBuilder.Configurations.Add(new ListMapping());
            modelBuilder.Configurations.Add(new ListItemMapping());
        }

        public DbSet<Category> Categories { get; set; }
        public DbSet<Item> Items { get; set; }
        public DbSet<Users> Users { get; set; }
        public DbSet<List> List { get; set; }
        public DbSet<ListItem> ListItem { get; set; }
    }
}
