﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sogeti.got.groceries.Data.DomainModels
{
    public class List
    {
        public int ListID { get; set; }
        public string ListName { get; set; }
        public int UserID { get; set; }

        //public virtual Users User { get; set; }
    }
}
