﻿using Sogeti.Got.Groceries.Data.DomainModels;
using System.Data.Entity.ModelConfiguration;

namespace Sogeti.Got.Groceries.Repository.Mapping
{
    class ItemMapping : EntityTypeConfiguration<Item>
    {
        public ItemMapping()
        {
            HasKey(t => t.IdItem);

            ToTable("Item", "dbo");

            HasRequired(t => t.Category)
                .WithMany(t => t.Items)
                .HasForeignKey(t => t.IdCategory);
        }
    }
}
