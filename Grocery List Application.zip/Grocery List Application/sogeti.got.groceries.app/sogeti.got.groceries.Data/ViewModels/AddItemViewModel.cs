﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sogeti.got.groceries.Data.ViewModels
{
    public class AddItemViewModel
    {
        public List<ItemViewModel> items { get; set; }
        public int categoryId { get; set; }


    }
}
