﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using sogeti.got.groceries.app.Controllers;
using sogeti.got.groceries.Data.ViewModels;

namespace sogeti.got.groceries.app.Tests.Controllers
{
    [TestClass]
    class UserControllerTest
    {

        [TestMethod]
        public void LogOnTest1()
        {
            UsersController controller = new UsersController();

            UserViewModel user = new UserViewModel();
            user.UserName = "john480";
            user.Password = "abc123";
            
            var result = controller.LogIn(user);
            Assert.IsNotNull(result);
            //Assert.IsTrue(result);
            
        }





    }
}
