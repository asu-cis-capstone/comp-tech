﻿using Sogeti.Got.Groceries.Business;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Sogeti.Got.Groceries.Controllers
{
    public class ItemController : Controller
    {
        private IItemManager _itemManager;

        public ItemController()
        {
            _itemManager = new ItemManager();
        }
        // GET: Item
        public ActionResult ShowItems()
        {
            var items = _itemManager.GetAllItems();
            return View(items);
        }
    }
}