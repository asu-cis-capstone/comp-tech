﻿using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.Data.Entity.Infrastructure;
using Sogeti.Got.Groceries.Data.DomainModels;
using Gogeti.Got.Groceries.Repository.Mapping;
using Sogeti.Got.Groceries.Repository.Mapping;

namespace Sogeti.Got.Groceries.Repository
{
    public class AppDbContext : DbContext
    {
        public AppDbContext()
            : base("name=GroceryListEntities")
        {
            Database.SetInitializer<AppDbContext>(null);
        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();

            modelBuilder.Configurations.Add(new CategoryMapping());
            modelBuilder.Configurations.Add(new ItemMapping());
            modelBuilder.Configurations.Add(new UserMapping());
        }

        public DbSet<Category> Categories { get; set; }
        public DbSet<Item> Items { get; set; }
        public DbSet<Users> Users { get; set; }
    }
}
