﻿using sogeti.got.groceries.Data.DomainModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using sogeti.got.groceries.Repository;
using sogeti.got.groceries.Data.ViewModels;
using AutoMapper;

namespace sogeti.got.groceries.Business
{
    public interface IUserManager
    {
        List<UserViewModel> GetAllItems();
        void AddUser(Users u);
        bool Login(Users u);
    }
    public class UserManager : IUserManager
    {
        private IUserRepository _userRepo;

        public UserManager()
        {
            _userRepo = new UserRepository();
        }

        public void AddUser(Users u)
        {
            _userRepo.AddUser(u);
        }

        public List<UserViewModel> GetAllItems()
        {
            var domainModel = _userRepo.GetAllItems();
            var viewModel = Mapper.Map<List<Users>, List<UserViewModel>>(domainModel);

            return viewModel;
        }

        public bool Login(Users u)
        {
            return IsValid(u.UserName, u.Password);
        }

        private bool IsValid(string userName, string password)
        {
            bool IsValid = false;

            using (var db = new Repository.AppDbContext())

            {
                var user = db.Users.FirstOrDefault(u => u.UserName == userName);

                if (user != null)
                {
                    if (user.Password == password)
                    {
                        IsValid = true;
                    }
                }
            }
            return IsValid;
        }
    }
}
